package miprimeraap.andriod.teaching.com.miprimeraapp;

public interface GameDetailView {
    void  onGameLoaded(GameModel game);
}
